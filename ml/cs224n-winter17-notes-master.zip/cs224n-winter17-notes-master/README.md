# Course notes for CS224N Winter17

Submit pull requests / open issues to help fix typos!
